package com.aig.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import java.util.Locale

private val Night = Color(0xFF090613)
private val Purple = Color(0xFF211747)
private val Gold = Color(0xFFFFC04D)
private val Aqua = Color(0xFF40F2E8)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var recognizedText by mutableStateOf("")
    private var statusText by mutableStateOf("Ready when you are.")
    private var notes by mutableStateOf(listOf<String>())
    private var tasks by mutableStateOf(listOf<String>())
    private val requestAudio = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else statusText = "Microphone permission was not granted."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Gold, secondary = Aqua, background = Night, surface = Purple,
                onPrimary = Night, onBackground = Color.White, onSurface = Color.White
            )) {
                AIGScreen(
                    status = statusText,
                    notes = notes,
                    tasks = tasks,
                    onListen = {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening()
                        else requestAudio.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onCommand = { handleCommand(it) },
                    onOpen = { openSite(it) },
                    onClearStatus = { statusText = "Ready when you are." }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.UK
    }

    private fun speak(message: String) {
        statusText = message
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "aig_reply")
    }

    private fun startListening() {
        val recognizer = speechRecognizer
        if (recognizer == null) {
            speak("Speech recognition is not available on this device. You can type a command instead.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-NG")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AIG")
        }
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { statusText = "Listening…" }
            override fun onBeginningOfSpeech() { statusText = "I’m listening…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText = "Processing…" }
            override fun onError(error: Int) { statusText = "Could not hear that. Try again or type your command." }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                recognizedText = words
                handleCommand(words)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        val lower = command.lowercase(Locale.ROOT)
        when {
            command.isBlank() -> speak("Tell me what you need.")
            lower.startsWith("save a note") || lower.startsWith("note ") -> {
                val body = command.substringAfter(":", command.substringAfter(" ", "")).trim()
                if (body.isBlank()) speak("Say or type note followed by your note.") else {
                    notes = notes + body
                    getSharedPreferences("aig", MODE_PRIVATE).edit().putString("notes", notes.joinToString("\n")).apply()
                    speak("Note saved on this phone.")
                }
            }
            lower.startsWith("add a task") || lower.startsWith("task ") -> {
                val body = command.substringAfter(":", command.substringAfter(" ", "")).trim()
                if (body.isBlank()) speak("Say or type task followed by your task.") else {
                    tasks = tasks + body
                    getSharedPreferences("aig", MODE_PRIVATE).edit().putString("tasks", tasks.joinToString("\n")).apply()
                    speak("Task added.")
                }
            }
            lower.contains("open youtube") -> openSite("youtube")
            lower.contains("open facebook") -> openSite("facebook")
            lower.contains("open google") || lower.startsWith("search ") -> {
                val query = if (lower.startsWith("search ")) command.substringAfter(" ", "") else ""
                val url = "https://www.google.com/search?q=" + Uri.encode(query)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                speak(if (query.isBlank()) "Opening Google." else "Searching Google for $query.")
            }
            lower.contains("open play store") -> {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.android.vending")))
                speak("Opening Play Store.")
            }
            lower.startsWith("calculate ") -> {
                val expression = command.substringAfter("calculate ").trim()
                val result = safeCalculate(expression)
                speak(result ?: "I can calculate basic expressions with numbers, plus, minus, multiply and divide. Try calculate 12 * 4.")
            }
            lower == "show notes" -> speak(if (notes.isEmpty()) "You have no saved notes yet." else "Your notes: " + notes.joinToString(". "))
            lower == "show tasks" -> speak(if (tasks.isEmpty()) "You have no tasks yet." else "Your tasks: " + tasks.joinToString(". "))
            lower == "help" -> speak("Try: open YouTube, open Facebook, search rabbits in Calabar, save a note: call supplier, add a task: clean hutches, calculate 12 times 4, show notes, or show tasks.")
            else -> speak("I can do basic offline tasks and open online apps. For that command, type search followed by what you want to find, or say help.")
        }
    }

    private fun safeCalculate(input: String): String? {
        val clean = input.replace("times", "*").replace("multiplied by", "*").replace("plus", "+").replace("minus", "-").replace("divided by", "/").replace(" ", "")
        if (!clean.matches(Regex("[0-9.+*/()\\-]+"))) return null
        return try {
            val tokens = Regex("(\\d+(?:\\.\\d+)?|[()+*/-])").findAll(clean).map { it.value }.toList()
            if (tokens.joinToString("") != clean) return null
            val parser = ArithmeticParser(tokens)
            val value = parser.parse()
            if (!value.isFinite()) null else "The answer is ${"%.4f".format(Locale.US, value).trimEnd('0').trimEnd('.')}."
        } catch (_: Exception) { null }
    }

    private fun openSite(site: String) {
        val url = when (site) {
            "youtube" -> "https://www.youtube.com/"
            "facebook" -> "https://www.facebook.com/"
            else -> "https://www.google.com/"
        }
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        speak("Opening ${site.replaceFirstChar { it.uppercase() }}.")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

private class ArithmeticParser(private val tokens: List<String>) {
    private var i = 0
    fun parse(): Double { val v = expr(); if (i != tokens.size) error("extra"); return v }
    private fun expr(): Double {
        var v = term()
        while (i < tokens.size && (tokens[i] == "+" || tokens[i] == "-")) {
            val op = tokens[i++]; val r = term(); v = if (op == "+") v + r else v - r
        }
        return v
    }
    private fun term(): Double {
        var v = factor()
        while (i < tokens.size && (tokens[i] == "*" || tokens[i] == "/")) {
            val op = tokens[i++]; val r = factor()
            if (op == "/" && r == 0.0) error("zero")
            v = if (op == "*") v * r else v / r
        }
        return v
    }
    private fun factor(): Double {
        if (i >= tokens.size) error("missing")
        val t = tokens[i++]
        if (t == "-") return -factor()
        if (t == "(") { val v = expr(); if (tokens.getOrNull(i++) != ")") error("paren"); return v }
        return t.toDouble()
    }
}

@Composable
private fun AIGScreen(
    status: String,
    notes: List<String>,
    tasks: List<String>,
    onListen: () -> Unit,
    onCommand: (String) -> Unit,
    onOpen: (String) -> Unit,
    onClearStatus: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Home") }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF21143F), Night, Color(0xFF05040A))))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("AIG", fontSize = 32.sp, fontWeight = FontWeight.Light, color = Color.White)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ExpandMore, contentDescription = "Menu", tint = Gold, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.height(22.dp))
            Box(Modifier.size(230.dp).background(Brush.radialGradient(listOf(Aqua.copy(alpha=.8f), Color(0xFF167D9A), Color(0xFF102040), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
                Box(Modifier.size(150.dp).background(Brush.radialGradient(listOf(Color(0xFF51FFF1), Color(0xFF176A91), Color(0xFF10203F))), CircleShape))
            }
            Spacer(Modifier.height(18.dp))
            Text(if (status.contains("Listening")) "AIG is listening…" else "AIG is ready…", fontSize = 27.sp, fontStyle = FontStyle.Italic, color = Color.White)
            Text(status, color = Color(0xFFB9B2D4), fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = onListen, shape = CircleShape, modifier = Modifier.size(68.dp), contentPadding = PaddingValues(0.dp)) { Icon(Icons.Default.Mic, contentDescription = "Speak") }
                Button(onClick = onListen, shape = CircleShape, modifier = Modifier.size(86.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF16A87)), contentPadding = PaddingValues(0.dp)) { Icon(Icons.Default.GraphicEq, contentDescription = "Listen", modifier = Modifier.size(32.dp)) }
                OutlinedButton(onClick = onClearStatus, shape = CircleShape, modifier = Modifier.size(68.dp), contentPadding = PaddingValues(0.dp)) { Icon(Icons.Default.Close, contentDescription = "Stop/status") }
            }
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("Type a command") }, placeholder = { Text("e.g. save a note: buy feed") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), singleLine = true)
            Button(onClick = { onCommand(input); input = "" }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Send command", color = Night) }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("YouTube", "Facebook", "Google", "Play Store").forEach { name ->
                    TextButton(onClick = { if (name == "Play Store") onCommand("open play store") else onOpen(name.lowercase()) }, modifier = Modifier.weight(1f)) {
                        Text(name, fontSize = 10.sp, color = Aqua)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Home", "Notes", "Tasks", "Settings").forEach { name ->
                    FilterChip(selected = page == name, onClick = { page = name }, label = { Text(name) })
                }
            }
            if (page == "Notes" || page == "Tasks") {
                val items = if (page == "Notes") notes else tasks
                LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false)) {
                    items(items) { item -> Text("• $item", color = Color.White, modifier = Modifier.fillMaxWidth().padding(8.dp)) }
                }
            } else if (page == "Settings") {
                Text("AIG • English • Dark space theme", color = Color(0xFFB9B2D4), modifier = Modifier.padding(12.dp))
                Text("Voice recognition may require internet, depending on your Android speech service.", color = Color(0xFFB9B2D4), fontSize = 12.sp)
            }
        }
    }
}
